from pypdf import PdfReader
from docx import Document


def extract_from_pdf(file):
    reader = PdfReader(file)

    text = ""

    for page in reader.pages:
        page_text = page.extract_text()

        if page_text:
            text += page_text + "\n"

    return text


def extract_from_docx(file):
    document = Document(file)

    text = ""

    for paragraph in document.paragraphs:
        text += paragraph.text + "\n"

    return text


def extract_from_txt(file):
    return file.read().decode("utf-8")


def extract_text(file):

    filename = file.name.lower()

    if filename.endswith(".pdf"):
        return extract_from_pdf(file)

    elif filename.endswith(".docx"):
        return extract_from_docx(file)

    elif filename.endswith(".txt"):
        return extract_from_txt(file)

    else:
        raise ValueError("Unsupported file type")