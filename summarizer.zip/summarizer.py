import os
import time
from dotenv import load_dotenv
from google import genai

load_dotenv()

API_KEY = os.getenv("GEMINI_API_KEY")

if not API_KEY:
    raise ValueError("GEMINI_API_KEY is missing from .env")

client = genai.Client(api_key=API_KEY)

MODEL_NAME = "gemini-3.8-flash"


def generate_response(prompt, retries=3):
    """
    Send a prompt to Gemini.
    Automatically retries temporary 503 errors.
    """

    for attempt in range(retries):

        try:
            response = client.models.generate_content(
                model=MODEL_NAME,
                contents=prompt
            )

            return response.text

        except Exception as e:

            error_message = str(e)

            if "503" in error_message and attempt < retries - 1:
                print(
                    f"Gemini is temporarily busy. "
                    f"Retrying ({attempt + 1}/{retries})..."
                )

                time.sleep(5)
                continue

            raise e


def summarize_text(text):

    prompt = f"""
You are a document summarization assistant.

Summarize the following medical report accurately.

Important rules:
- Only use information present in the report.
- Do not invent medical information.
- Do not make a new diagnosis.
- Do not recommend medicines or treatments.
- Preserve important medical values, test results, dates,
  medications and observations when present.
- Use simple language.
- Clearly mention important abnormal or notable findings
  only when they are explicitly stated or clearly indicated
  by the report.

Format the response as:

1. Overall Summary
2. Important Findings
3. Test Results
4. Medications Mentioned
5. Other Important Information

Medical Report:
{text}
"""

    return generate_response(prompt)


def split_text(text, chunk_size=6000):

    words = text.split()

    chunks = []

    current_chunk = []
    current_length = 0

    for word in words:

        current_chunk.append(word)
        current_length += len(word) + 1

        if current_length >= chunk_size:
            chunks.append(" ".join(current_chunk))
            current_chunk = []
            current_length = 0

    if current_chunk:
        chunks.append(" ".join(current_chunk))

    return chunks


def summarize_long_text(text):

    chunks = split_text(text)

    summaries = []

    for i, chunk in enumerate(chunks):

        prompt = f"""
Summarize this section of a medical report.

Rules:
- Use only information in the provided text.
- Do not invent information.
- Do not diagnose the patient.
- Keep important medical values and observations.

Section:

{chunk}
"""

        summary = generate_response(prompt)
        summaries.append(summary)

    combined = "\n\n".join(summaries)

    final_prompt = f"""
Create one clear final summary from the following
section summaries of a medical report.

Rules:
- Do not add information that is not present.
- Do not make a diagnosis.
- Do not recommend treatment.
- Remove repeated information.
- Preserve important test results and observations.

Format:

1. Overall Summary
2. Important Findings
3. Test Results
4. Medications Mentioned
5. Other Important Information

Section summaries:

{combined}
"""

    return generate_response(final_prompt)