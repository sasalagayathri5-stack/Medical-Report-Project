import streamlit as st

from utils.extract_text import extract_text
from utils.text_cleaner import clean_text
from utils.summarizer import summarize_text, summarize_long_text


st.set_page_config(
    page_title="AI Medical Report Summarizer",
    page_icon="🩺",
    layout="wide"
)


st.title("🩺 AI Medical Report Summarizer")

st.write(
    "Upload a medical report and generate an AI-powered summary."
)


st.warning(
    "This application summarizes the uploaded document. "
    "It is not a substitute for professional medical advice."
)


uploaded_file = st.file_uploader(
    "Upload your document",
    type=["pdf", "txt", "docx"]
)


if uploaded_file is not None:

    st.success(f"File uploaded: {uploaded_file.name}")

    if st.button("Generate Summary"):

        try:

            # Step 1: Extract text
            with st.spinner("Extracting text..."):

                text = extract_text(uploaded_file)

            if not text.strip():

                st.error(
                    "No text could be extracted from this file."
                )

                st.stop()


            # Step 2: Clean text
            with st.spinner("Cleaning text..."):

                cleaned_text = clean_text(text)


            # Step 3: Show extracted text
            with st.expander("View Extracted Text"):

                st.text_area(
                    "Extracted Text",
                    cleaned_text,
                    height=300
                )


            # Step 4: Summarization
            with st.spinner("Generating summary..."):

                if len(cleaned_text) <= 12000:

                    summary = summarize_text(
                        cleaned_text
                    )

                else:

                    summary = summarize_long_text(
                        cleaned_text
                    )


            # Step 5: Display summary
            st.subheader("📋 Medical Report Summary")

            st.markdown(summary)


            # Step 6: Download
            st.download_button(
                label="📥 Download Summary",
                data=summary,
                file_name="medical_report_summary.txt",
                mime="text/plain"
            )

        except Exception as e:

            st.error(
                f"An error occurred: {str(e)}"
            )